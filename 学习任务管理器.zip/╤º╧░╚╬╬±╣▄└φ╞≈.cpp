﻿#include <iostream>
#include<fstream>
#include<cstdlib>
#include <time.h>
#include <Windows.h>
using namespace std;
struct weekpln
{
    int end;
    char name[100];
    int rd;
};
struct unit
{
    char uni[100];
    int control;
    int rev;
};
struct object
{
    char name[100];
    unit dan_yuan[50];
    int unit_has_stu;
};
struct xxjh
{
    int di;
    string name;
    int zongshu;
};
xxjh* task = { new xxjh[100] };
int num_of_jsb = 0;
int num_plans = 0;
int kaixueriqi = 0;
int kai_xue_nian;
object ke_mu[15];
weekpln week_plan[20];
int is_newuser=1;
int
week_plan_has_end = 0;
int zonglan_YN;
int
week_plan_del = 0;
int
week_plan_del_end = 0;
int weeks = 0;
int ke_mu_shu = 0; void zong_lan();
void weekplan_cout();
void gettime(); 
int GetDay(int Year, int Month, int Day);
void setting();
void clear();
void update_unit(int sub);
void weekplan_xiugai();
void updatediary();
void ui();
void jsbbb(int a);
void weekplan_lr();
void saving();
void updating();
void weekplan_save();
void LR_insert_obj();
void weekplan_load();
void about();
void weekplan_rd();
void weekplan_del();
void read_unit(int sub);
void RD_obj();
void main_2();
void random();

void helping()
{
    system("cls");
    cout << "\n  帮    助\n────────────────────────────────────────────────────────────────────────────────────────\n";
    cout << "\n  欢迎使用学习计划表程序！\n\n  【关于】";
    cout << "\n    本程序为学习计划管理程序。";
    cout << "\n    两个功能：分学科分单元学习计划和周计划。";
    cout << "\n    附加了日期显示功能（相关数据设置见【设置】菜单）";
    cout << "\n    附加了记事本功能（相关数据设置见【设置】菜单）";
    cout << "\n    运行期间会产生两个数据文件，请勿删除\n";
    cout << "\n  【使用说明】";
    cout << "\n    输入菜单选项前面的序号，按Enter确认。";
    cout << "\n";
    cout << "\n  【功能介绍】";
    cout << "\n    1.本学期各科学习任务";
    cout << "\n    2.周计划，支持快捷操作";
    cout << "\n    3.记事本，支持快捷记事";
    cout << "\n    4.日历功能，距离期末天数";
    cout << "\n    5.可以设置启动时显示计划总览\n\n";
    cout << "\n    水平有限，系统尚不完善，欢迎指正！\n\n";
    system("pause");
};

void update_unit(int sub)
{
    read_unit(sub); int s; int a, b, c;
    cout << "\n选择单元号：\n";
    cin >> a;
    if (a == 0)
        return;
    cout << "掌握程度："; cin >> b; cout << "是否复习(1/0)："; cin >> c;
    ke_mu[sub].dan_yuan[a - 1].control = b;
    ke_mu[sub].dan_yuan[a - 1].rev = c;
    cout << "已更新";

}
void updating()
{
    int i = ke_mu_shu; int s;
    while (1)
    {
        i = ke_mu_shu;
        system("cls");
        cout << "\n  选择更新的科目：\n────────────────────────────────────────────────────────────────────────────────────────\n";
        while (i)
        {
            cout << "  [" << ke_mu_shu - i + 1 << "]." << ke_mu[ke_mu_shu - i].name << endl << endl;
            i--;
        }
        cout << "\n\n\n──────────────────────────────────────────────────────────────────────────────────────── \n";
        cin >> s;
        if (s == 0)
            break;
        update_unit(s - 1);
    }
}
void LR_insert_obj()
{
    int obj;
    int s;
    while (1)
    {
        getchar();
        cout << "输入科目名称：";
        gets_s(ke_mu[ke_mu_shu].name);



        obj = ke_mu_shu;

        {
            int aa;
            cout << "\n输入单元数：";
            cin >> aa;
            getchar();
            ke_mu[obj].unit_has_stu = aa;

            cout << "\n输入任务名称：";
            while (aa)
            {
                cout << "第" << ke_mu[obj].unit_has_stu - aa + 1 << "单元：";
                gets_s(ke_mu[obj].dan_yuan[ke_mu[obj].unit_has_stu - aa].uni);




                ke_mu[obj].dan_yuan[ke_mu[obj].unit_has_stu - aa].control = 0;




                ke_mu[obj].dan_yuan[ke_mu[obj].unit_has_stu - aa].rev = 0;



                aa--;
            }
        }



        ke_mu_shu++;
        cout << "是否继续添加科目？   [1]是   [2]否\n"; cin >> s;
        if (s == 2)
        {
            break;
        }
    }
}
void read_unit(int sub)//读取
{
    system("cls");
    cout << endl << "  " << ke_mu[sub].name;
    cout << "\n────────────────────────────────────────────────────────────────────────────────────────\n  单元:";
    cout << ke_mu[sub].unit_has_stu << "\n────────────────────────────────────────────────────────────────────────────────────────\n";
    for (int i = 0; i < ke_mu[sub].unit_has_stu; i++)
    {
        cout << endl << "  " << i + 1 << "." << ke_mu[sub].dan_yuan[i].uni << "\n ";// << ke_mu[sub].dan_yuan[i].control << "\t       ";
        if (ke_mu[sub].dan_yuan[i].control == 0)
        {
            cout << "    还没学\t";
        }
        if (ke_mu[sub].dan_yuan[i].control == 1)
        {
            cout << "    只会一点点\t";
        }
        if (ke_mu[sub].dan_yuan[i].control == 2)
        {
            cout << "    还凑合\t";
        }
        if (ke_mu[sub].dan_yuan[i].control == 3)
        {
            cout << "    已掌握\t";
        }
        if (ke_mu[sub].dan_yuan[i].rev == 1)
            cout << "已复习";
        else
            cout << "未复习";
        if (ke_mu[sub].dan_yuan[i].rev == 1 && ke_mu[sub].dan_yuan[i].control == 3)
            cout << "\t√";
        cout << endl;
    }
    cout << "\n────────────────────────────────────────────────────────────────────────────────────────\n";
}
void RD_obj()
{
    system("cls");
    int i = ke_mu_shu;
    cout << "\n  选择科目：\n────────────────────────────────────────────────────────────────────────────────────────\n";
    while (i)
    {
        cout << "  " << ke_mu_shu - i + 1 << "." << ke_mu[ke_mu_shu - i].name << endl << endl;
        i--;
    }

    cout << "\n\n\n────────────────────────────────────────────────────────────────────────────────────────\n                            [0]返回";
    int s;
    cin >> s;
    if (s != 0)read_unit(s - 1);
    system("pause");

}
void jiemian()
{
    system("cls");
    ui();
    cout << "────────────────────────────────────────────────────────────────────────────────────────\n   【主菜单】 \n\n";
    cout << "       [1]快速添加计划          [2]快速记事             [3]记事本           [4]计划总览\n\n       [5]本学期任务(共" << ke_mu_shu << "科)     [6]周计划               [7]设置             [8]抽签\n\n";
    cout << "       [9]帮助                     2022.4 by @对江邀月 v1.3                 [0]退出\n";
    cout << "\n────────────────────────────────────────────────────────────────────────────────────────";
    gettime();
    cout << "\n────────────────────────────────────────────────────────────────────────────────────────\n";
    weekplan_load();
}
void jiemian_new()
{
    int s;
    system("cls");
    cout << " \n     本学期任务管理\n────────────────────────────────────────────────────────────────────────────────────────\n   Press a key of choice... \n\n";
    cout << "       [1]加入学科任务          [2]更新课程学习进度          [3]查看学习进度(" << ke_mu_shu << ")\n\n       [4]清除计划                      ";
    cout << "                                   \n";
    cout << "\n────────────────────────────────────────────────────────────────────────────────────────";


    cout << "\n  输入选项序号，[0]退出...\n";

    cin >> s;
    if (s == 1)
    {
        LR_insert_obj(); saving();
    }
    if (s == 4)
    {
        ke_mu_shu = 0; saving();
        cout << "\n已清除"; getchar();
    }
    if (s == 3)
    {
        RD_obj();
    }
    if (s == 2)
    {

        {updating(); saving(); }
    }
}
void reading_file()
{
    cout << "loading...";

    ifstream infile;
    infile.open("学习任务.txt");
    infile >> ke_mu_shu;/////////////////
    int obj;
    int s = ke_mu_shu;
    int kms = 0;
    while (s)
    {
        infile >> ke_mu[kms].name;///////



        obj = kms;

        {
            int aa;
            infile >> ke_mu[obj].unit_has_stu;
            aa = ke_mu[obj].unit_has_stu;
            while (aa)
            {
                infile >> ke_mu[obj].dan_yuan[ke_mu[obj].unit_has_stu - aa].uni;
                infile >> ke_mu[obj].dan_yuan[ke_mu[obj].unit_has_stu - aa].control;
                infile >> ke_mu[obj].dan_yuan[ke_mu[obj].unit_has_stu - aa].rev;
                aa--;
            }
        }
        kms++; s--;
    }
    infile >> num_of_jsb;
    for (int i = 1; i <= num_of_jsb; i++)
    {
        infile >> task[i].name;
    }
    infile.close();
    infile.open("配置文件.txt"); cout << "l-o-a-d-i-n-g...";
    infile >> is_newuser;/////////////////
    infile >> zonglan_YN;/////////////////
    infile >> kai_xue_nian;/////////////////
    infile >> weeks;/////////////////
    infile >> kaixueriqi;/////////////////
    infile >> num_of_jsb; cout << "l--o--a--d--i--n--g...";
    for (int i = 1; i <= num_of_jsb; i++)
    {
        infile >> task[i].name;
    }
    infile.close();
}
void saving()
{
    int kemushu = ke_mu_shu;
    int k = 0;
    ofstream outfile; int obj;
    outfile.open("学习任务.txt");
    outfile << ke_mu_shu << endl;
    while (kemushu)
    {cout << "保存学习任务...";

        obj = k;

        outfile << ke_mu[obj].name << endl;


        {
            int aa = ke_mu[obj].unit_has_stu;
            


            outfile << ke_mu[obj].unit_has_stu << endl;


            while (aa)
            {

                outfile << ke_mu[obj].dan_yuan[ke_mu[obj].unit_has_stu - aa].uni << endl;

                outfile << ke_mu[obj].dan_yuan[ke_mu[obj].unit_has_stu - aa].control << endl;

                outfile << ke_mu[obj].dan_yuan[ke_mu[obj].unit_has_stu - aa].rev << endl;


                aa--;
            }

        }

        k++;

        kemushu--;

    }
    
    outfile.close();
    outfile.open("配置文件.txt"); cout << "保存设置...";
    outfile << is_newuser << endl;
    outfile << zonglan_YN << endl;
    outfile << kai_xue_nian << endl;
    outfile << weeks << endl;
    outfile << kaixueriqi << endl;
    outfile << num_of_jsb << endl; cout << "保存记事本...";
    for (int i = 1; i <= num_of_jsb; i++)
    {
        outfile << task[i].name << endl;
    }
    outfile.close();
    cout << "saved";
}
void ui() {
    system("color 0E");

    cout << "\n         ┌────┐                                                          ┌────┐\n";
    cout << "        ┌┴────┴┐                                                        ┌┴────┴┐\n";
    cout << "        │      ├────────────────────────────────────────────────────────┤      │\n";
    cout << "        │      │                                                        │      │\n";
    cout << "        │      ├─┬─┬─┬─┬─┬─┬────────────────────────────────┬─┬─┬─┬─┬─┬─┤      │\n";
    cout << "        │      │ │ │ │ │ │ │                                │ │ │ │ │ │ │      │\n";
    cout << "        │      │ │ │ │ │ │ │                                │ │ │ │ │ │ │      │\n";
    cout << "        │      │ │ │ │ │ │ │                                │ │ │ │ │ │ │      │\n";
    cout << "        │      │ │ │ │ │ │ │                                │ │ │ │ │ │ │      │\n";
    cout << "        │      │ │ │ │ │ │ │                                │ │ │ │ │ │ │      │\n";
    cout << "        │      │ │ │ │ │ │ │                                │ │ │ │ │ │ │      │\n";
    cout << "        ├──────┤ ├─┤ ├─┤ ├─┤                                ├─┤ ├─┤ ├─┤ ├──────┤\n";
    cout << "────────┴──────┴─┴─┴─┴─┴─┴─┴────────────────────────────────┴─┴─┴─┴─┴─┴─┴──────┴────────\n";
    cout << "\n                      学    习    任    务    管    理    系    统\n";

}

void weekplan()
{
    int s;
    float rate;
    printf("loading");
    system("cls");
    for (;;)
    {
        system("cls");
        cout << "\n    周计划\n────────────────────────────────────────────────────────────────────────────────────────\n\n";
        rate = (float)week_plan_has_end / num_plans;
        cout << "\n    [1]制定计划        [2]查看计划        [3]修改计划        [4]删除计划\n\n    计划数：" << num_plans << "\n    已完成：" << week_plan_has_end << "\n    完成度：" << 100 * rate << "%\n────────────────────────────────────────────────────────────────────────────────────────────────────────";

        cin >> s;
        if (s == 1)
        {
            weekplan_lr();
            weekplan_save();
        }
        if (s == 2)
        {
            weekplan_rd();
            weekplan_save();
        }
        if (s == 9)
        {
            clear();
            system("cls");
            cout << "已清空";
            system("pause");
        }

        if (s == 4)
        {
            weekplan_del();
            weekplan_save();
            cout << "已删除，请重启系统\n";
            system("pause");
            exit(0);
            break;
        }
        if (s == 3)
        {
            weekplan_xiugai();
        }
        if (s == 0)
        {
            weekplan_save();
            cout << "已保存";
            break;
        }
    }
}
void main_2()
{
    reading_file();
    weekplan_load();
    int s;
    system("color 0E");
    if (is_newuser)
    {
        is_newuser = 0;
        helping();
    }
    if (zonglan_YN)
    {
        zong_lan();
    }
    for (;;)
    {
        jiemian();
        cin >> s;
        if (s == 5)
        {
            jiemian_new();
        }
        if (s == 6)
        {
            weekplan();
        }
        if (s == 0)
        {
            saving();
            break;
        }
        if (s == 7)
        {
            setting();
        }
        if (s == 1)
        {
            weekplan_lr();
            weekplan_save();
        }
        if (s == 3)
        {
            jsbbb(0);
        }
        if (s == 4)
        {
            zong_lan();
        }
        if (s == 8)
        {
            random();
        }
        if (s == 9)
        {
           helping();
        }
        if (s == 2)
        {
            jsbbb(1);

        }
        saving();
    }
}


int main(int argc, char** argv)
{
    week_plan_has_end = 0;

    week_plan_del = 0;

    week_plan_del_end = 0;
    ke_mu_shu = 0;
    main_2(); return 0;
}

void weekplan_load()
{

    ifstream infile;
    infile.open("周计划.txt");

    int i;
    i = 0;
    infile >> num_plans;
    infile >> week_plan_has_end;
    while (i < num_plans)
    {
        infile >> week_plan[i].name;
        infile >> week_plan[i].end;
        i++;
    }
    infile.close();
}
void weekplan_rd()
{
    system("cls");
    cout << "\n    本周计划\n────────────────────────────────────────────────────────────────────────────────────────\n\n";
    weekplan_cout();
    cout << "完成了哪项计划？\n"; int a;
    while (1)
    {
        cin >> a;
        if (a == 0)
            break;
        if (week_plan[a - 1].end == 0 && a != 0)
        {
            week_plan[a - 1].end = 1;
            week_plan_has_end++;
        }
    }
}
void weekplan_lr()
{
    int s;
    while (1)
    {
        week_plan[num_plans].end = 0;
        week_plan[num_plans].rd = 0;
        cout << "输入计划名称：";
        cin >> week_plan[num_plans].name;
        num_plans++;
        cout << "是否继续添加？   [1]是   [2]否\n"; cin >> s;
        if (s == 2)
            break;
    }
}
void weekplan_save()
{
    ofstream outfile; int n = 0;
    outfile.open("周计划.txt");
    outfile << num_plans - week_plan_del << endl;
    outfile << week_plan_has_end - week_plan_del_end << endl;
    while (n < num_plans)
    {
        if (week_plan[n].rd == 0)
        {


            outfile << week_plan[n].name << endl;
            outfile << week_plan[n].end << endl;
        }
        n++;
    }num_plans = num_plans - week_plan_del; week_plan_has_end = week_plan_has_end - week_plan_del_end;
    week_plan_del = 0; week_plan_del_end = 0;
    outfile.close();
}
void clear()
{
    week_plan_has_end = 0;
    num_plans = 0;
}
void weekplan_xiugai()
{
    char newname[100];
    system("cls");
    cout << "\n    修改计划\n────────────────────────────────────────────────────────────────────────────────────────\n\n";
    weekplan_cout();
    cout << "修改哪项计划？[0]返回\n"; int a;
    while (1)
    {
        cin >> a;
        if (a == 0)
            break; getchar(); cout << "\n输入新的计划：";
        gets_s(newname);
        strcpy_s(week_plan[a - 1].name, newname);
    }
}
void weekplan_cout()
{
    int i = 0;
    while (i < num_plans)
    {
        cout << "  " << i + 1 << "." << week_plan[i].name << "   ";
        if (week_plan[i].end == 1)
            cout << "√" << endl;
        else cout << "O\n";
        cout << endl;
        i++;

    }
}
void weekplan_del()
{
    system("cls");
    week_plan_del = 0;
    week_plan_del_end = 0;
    cout << "\n    删除计划\n────────────────────────────────────────────────────────────────────────────────────────\n\n";
    weekplan_cout();
    cout << "删除哪项计划？[0]返回\n";
    int a;
    while (1)
    {
        cin >> a;
        if (a == 0)
            break;
        week_plan[a - 1].rd = 1;//删除标志
        week_plan_del++;
        if (week_plan[a - 1].end == 1)
            week_plan_del_end++;
    }
    cout << "已删除，继续删除请重启程序\n";
    cin.get();
}
int GetDay(int Year, int Month, int Day)
{
    int MonthDays[13] = { 0, 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31 };
    if ((Year % 4 == 0 && Year % 100 != 0) || (Year % 400 == 0))
        ++MonthDays[2];
    int Days = 0;
    for (int i = 1; i < Month; ++i)
        Days += MonthDays[i];
    Days += Day;
    return Days;
}
void gettime()
{
    char week[8][3] = { "日","一", "二", "三", "四", "五", "六" };
    time_t tp;
    struct tm p;
    time(&tp);
    localtime_s(&p, &tp);
    if (weeks == 0)
    {
        cout << "\n              【请设置时间...】\n";
    }
    cout << "\n\n       " << 1900 + p.tm_year << "年 " << 1 + p.tm_mon << "月 " << p.tm_mday << "日，星期" << week[p.tm_wday];
    int kai_xue_di = (p.tm_yday - kaixueriqi + 2);
    if (1900 + p.tm_year > kai_xue_nian)
    {
        kai_xue_di = kai_xue_di + 365;
        if ((kai_xue_nian % 4 == 0 && kai_xue_nian % 100 != 0) || (kai_xue_nian % 400 == 0))
            kai_xue_di = kai_xue_di + 1;
    }

    cout << "       开学第" << kai_xue_di << "天，本周为第" << kai_xue_di / 7 + 1 << "周";

    cout << "       距期末" << weeks * 7 - kai_xue_di << "天(";
    printf("%.2f", (float)(100 * kai_xue_di) / (weeks * 7));
    cout << "%)   \n";
}
void setting()
{
    system("cls");
    cout << "\n    设    置\n────────────────────────────────────────────────────────────────────────────────────────\n\n";
    cout << "    [1]设置开学时间\n"; cout << "    [2]设置本学期星期数\n    [3]更新日志\n    [4]关于\n    [5]设置启动是否显示计划总览界面[" << zonglan_YN << "]\n"; cout << "    [0]返回\n";
    int s;
    cin >> s;
    if (s == 1)
    {
        int n, y, r;
        system("cls");
        cout << "输入日期：年/月/日";
        cin >> n >> y >> r;
        kai_xue_nian = n;
        kaixueriqi = GetDay(n, y, r);
        cout << kaixueriqi; system("pause");
    }
    if (s == 3)
        updatediary();
    if (s == 5)
    {
        cout << "\n设置启动是否显示计划总览界面:[1]是  [0]否";
        cin >> zonglan_YN;
    }
    if (s == 4)
        about();
    if (s == 2)
    {
        cout << "\n输入这学期周数：";
        cin >> weeks;
    }
}
void updatediary()
{
    system("cls");
    cout << "\n    更新日志\n────────────────────────────────────────────────────────────────────────────────────────\n";
    cout << "\n    2022.3.2  编写最初版本。";
    cout << "\n    2022.3.4  加入\"周计划\"功能。";
    cout << "\n    2022.3.6  \"周计划\"功能支持修改删除。";
    cout << "\n    2022.3.8  加入日期功能。";
    cout << "\n    2022.3.23  优化日期显示。";
    cout << "\n    2022.3.24  加入选择困难抽签功能。";
    cout << "\n    2022.4.3  加入记事本，优化界面，修复已知问题。";
    cout << "\n\n\n";
    system("pause");
}
void about()
{
    {
        system("cls");
        cout << "\n    关    于\n────────────────────────────────────────────────────────────────────────────────────────\n";
        cout << "\n    本程序为学习计划管理程序。";
        cout << "\n    两个功能：分学科分单元学习计划和周计划。";
        cout << "\n    附加了日期显示功能（相关数据设置见【设置】菜单）";
        cout << "\n    附加了记事本功能（相关数据设置见【设置】菜单）";
        cout << "\n    运行期间会产生两个数据文件，请勿删除";
        cout << "\n    水平有限，系统尚不完善，欢迎指正！";
        cout << "\n\n                                    2022.3 by_@对江邀月\n";
        cout << "\n\n\n";
        system("pause");
    }
}
void random()
{
    cout << "  ";
    for (int i = 0; i < 3; i++)
    {
        printf("\b/");
        Sleep(60);
        printf("\b-");
        Sleep(60);
        printf("\b\\");
        Sleep(60);
        printf("\b|");
        Sleep(60);
    }
    srand((int)time(NULL));
    int a;
    while (1)
    {
        a = rand() % num_plans;
        if (week_plan[a].end == 0)
        {
            cout << endl << "\n  抽中：  " << a + 1 << " ";
            cout << week_plan[a].name << endl;
            break;
        }
    }
    system("pause");
}
void zong_lan()
{
    system("cls");
    cout << "\n    计划总览\n────────────────────────────────────────────────────────────────────────────────────────\n";
    int i = ke_mu_shu;
    cout << "  本学期学习任务：\n\n";
    if (i == 0)
        cout << "    【无任务】";
    while (i)
    {
        int m = 0, n = 0;
        for (int a = 0; a < ke_mu[ke_mu_shu - i].unit_has_stu; a++)
        {
            m = m + ke_mu[ke_mu_shu - i].dan_yuan[a].control;
            n = n + ke_mu[ke_mu_shu - i].dan_yuan[a].rev;
        }
        cout << "  " << ke_mu_shu - i + 1 << "." << ke_mu[ke_mu_shu - i].name;
        cout << "\t  进度:" << m << "/" << 4 * ke_mu[ke_mu_shu - i].unit_has_stu << "，复习:" << n << "/" << ke_mu[ke_mu_shu - i].unit_has_stu;
        if (m == 3 * ke_mu[ke_mu_shu - i].unit_has_stu && n == ke_mu[ke_mu_shu - i].unit_has_stu)
        {
            cout << "  √";
        }
        cout << "\n"; i--;
    }
    cout << "────────────────────────────────────────────────────────────────────────────────────────\n  本周学习计划：\n\n";
    int ii = 0;
    while (ii < num_plans)
    {
        cout << "  " << ii + 1 << "." << week_plan[ii].name << "   ";
        if (week_plan[ii].end == 1)
            cout << "√" << endl;
        else cout << "O\n";
        ii++;

    }
    if (num_of_jsb)
    {
        cout << "────────────────────────────────────────────────────────────────────────────────────────\n  记事本：\n\n";
        for (i = 1; i <= num_of_jsb; i++)
        {
            cout << "  " << i << "." << task[i].name << "\n";
        }
        cout << "\n────────────────────────────────────────────────────────────────────────────────────────\n                            ";
    }system("pause");
}
void jsbbb(int a)
{

    int aa, c, i;
    int  j;
    reading_file();
    system("cls");
    cout << "\n  记 事 本\n\n     [1]新建\n     [2]查看(" << num_of_jsb << ")\n     [3]管理\n     [0]返回\n";

    cout << "\n──────────────────\n";

    if (num_of_jsb == 0)
    {
        cout << "\n  【无记录】\n";
    }
    else
    {
        cout << "\n  已保存：\n";
        for (i = 1; i <= num_of_jsb; i++)
        {
            cout << "   " << task[i].name << "\t\t" << "\n";
        }
        cout << "  总共" << num_of_jsb << "条记录。";
    }

    if (a == 0)
        cin >> a;
    system("cls");
    if (a == 1)
    {
        for (i = num_of_jsb + 1; i < 16; i++)
        {
            cout << "\n  新    建\n──────────────────\n\n";
            task[i].di = num_of_jsb + 1;
            cin >> task[i].name;
            j = i; num_of_jsb = num_of_jsb + 1;
            break;

        }
        saving();

    }
    if (a == 3)
    {
        system("cls");
        cout << "\n    管    理\n──────────────────\n     [1]删除\n\n     [2]修改\n\n     [3]清除\n\n     [4]返回";
        cin >> a;
        if (a == 1)
        {
            system("cls");
            cout << "\n  删    除\n──────────────────\n";
            if (num_of_jsb == 0)
                cout << "无";
            else {
                for (i = 1; i <= num_of_jsb; i++)
                {
                    cout << "   " << task[i].name << "\t\t" << "\n";
                }
                cout << "  总共" << num_of_jsb << "条记录。";
                cout << "删除第几个？";
                cin >> aa;
                if (aa <= num_of_jsb)
                {
                    for (i = aa; i < num_of_jsb; i++)
                    {
                        task[i].name = task[i + 1].name;
                    }
                    num_of_jsb = num_of_jsb - 1;
                }
                else
                    if (aa == 1)
                    {
                        delete[] task;
                        num_of_jsb = 0;
                    }
                    else
                        cout << "没有找到此项";

            }saving();
        }
        if (a == 3)
        {
            system("cls");
            cout << "\n  清    除\n──────────────────\n\n\n\n";
            delete[] task;
            num_of_jsb = 0;
            cout << "清除成功"; saving();
        }

        if (a == 2)
        {
            system("cls");
            cout << "\n  修    改\n──────────────────\n\n\n\n";
            if (num_of_jsb == 0)
            {
                cout << "无";
            }
            for (i = 1; i <= num_of_jsb; i++)
            {
                cout << "   " << task[i].name << "\t\t" << "\n";
            }
            cout << "  总共" << num_of_jsb << "条记录。";
            cout << "修改第几个？";
            cin >> a;
            cout << "新文本：";
            cin >> task[a].name; saving();
        }
    }
    if (a == 0)
    {
        saving();
    }

}
